export type GestureType = 'open_hand' | 'two_fingers' | 'fist' | 'none';

export interface LivePhoto {
  id: string;
  title: string;
  location: string;
  year: string;
  imageUrl: string;
  description: string;
  accentColor: string;
  vibe: 'neon' | 'brutalist' | 'chrome' | 'vintage';
}

export interface Particle {
  id: number;
  emoji: string;
  x: number; // percentage from left (0 to 100)
  y: number; // percentage from top (0 to 100)
  size: number; // font size in px
  rotation: number;
  speedY: number;
  speedX: number;
  opacity: number;
}
