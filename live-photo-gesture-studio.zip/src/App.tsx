import React, { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX, Camera, RefreshCw, AlertTriangle, Shield, Power } from 'lucide-react';

import fotoKitaBlurMp3 from './assets/foto-kita-blur.mp3';
import jokowiLawanMp3 from './assets/jokowi-lawan.mp3';
import heyAntekAsingMp3 from './assets/hey-antek-asing.mp3';
import jokowiOamatiketuMp3 from './assets/jokowi-oamatiketu.mp3';
import metalMp3 from './assets/metal.mp3';

class WebAudioPlayer {
  private ctx: AudioContext | null = null;
  private buffers: Record<string, AudioBuffer> = {};
  private activeSources: Record<string, AudioBufferSourceNode> = {};
  private activeGain: Record<string, GainNode> = {};
  public globalMuted: boolean = false;
  private globalVolume: number = 0.85;

  async initCtx() {
    try {
      if (!this.ctx) {
        this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      if (this.ctx && this.ctx.state === 'suspended') {
        await this.ctx.resume();
      }
    } catch (e) {
      console.warn("Failed to init AudioContext:", e);
    }
  }

  async loadUrl(url: string) {
    if (this.buffers[url]) return;
    try {
      const response = await fetch(url);
      const arrayBuffer = await response.arrayBuffer();
      if (!this.ctx) await this.initCtx();
      const audioBuffer = await this.ctx!.decodeAudioData(arrayBuffer);
      this.buffers[url] = audioBuffer;
    } catch (e) {
      console.error(`Failed to load audio from ${url}`, e);
    }
  }

  async play(url: string, loop: boolean) {
    await this.initCtx();
    if (this.globalMuted || !this.ctx || !this.buffers[url]) {
      return Promise.resolve();
    }
    
    this.stop(url);

    const source = this.ctx.createBufferSource();
    source.buffer = this.buffers[url];
    source.loop = loop;
    
    const gainNode = this.ctx.createGain();
    gainNode.gain.value = this.globalVolume;
    
    source.connect(gainNode);
    gainNode.connect(this.ctx.destination);
    
    source.start(0);
    this.activeSources[url] = source;
    this.activeGain[url] = gainNode;
    
    return Promise.resolve();
  }

  stop(url: string) {
    if (this.activeSources[url]) {
      try {
        this.activeSources[url].stop();
        this.activeSources[url].disconnect();
      } catch (e) {}
      delete this.activeSources[url];
      delete this.activeGain[url];
    }
  }
  
  isPlaying(url: string) {
    return !!this.activeSources[url];
  }
  
  setVolume(url: string, vol: number) {
    if (this.activeGain[url]) {
      this.activeGain[url].gain.value = vol;
    }
  }
}

const audioPlayer = new WebAudioPlayer();

class ReliableAudio {
  public loop: boolean = false;
  
  constructor(public src: string) {
    audioPlayer.loadUrl(src);
  }
  
  get volume() { return 1; }
  set volume(v: number) { audioPlayer.setVolume(this.src, v); }
  get paused() { return !audioPlayer.isPlaying(this.src); }
  set currentTime(v: number) { /* No-op for buffer */ }
  
  play() {
    return audioPlayer.play(this.src, this.loop);
  }
  pause() {
    audioPlayer.stop(this.src);
  }
}

// Persistent HTMLAudioElements replaced with ReliableAudio to guarantee playback
const audioBlur = new ReliableAudio(fotoKitaBlurMp3);
audioBlur.loop = true;

const audioLawan = new ReliableAudio(jokowiLawanMp3);
audioLawan.loop = true;

const audioAsing = new ReliableAudio(heyAntekAsingMp3);
audioAsing.loop = true;

const audioTelunjuk = new ReliableAudio(jokowiOamatiketuMp3);
audioTelunjuk.loop = true;

const audioMetal = new ReliableAudio(metalMp3);
audioMetal.loop = true;

// Web Audio API Synthesizer as a 100% reliable fallback (Keep empty mock to avoid breaking references)
class WebAudioSynth {
  initCtx() {}
  play(type: any) {}
  stop() {}
  setVolume(v: any) {}
}
const synthFallback = new WebAudioSynth();

export default function App() {
  const [isSystemActive, setIsSystemActive] = useState(false);
  const [currentMode, setCurrentMode] = useState<'normal' | 'blur' | 'lawan' | 'mabuk' | 'telunjuk' | 'metal'>('normal');
  
  // Camera & MediaPipe loading states
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraLoading, setCameraLoading] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [requestState, setRequestState] = useState<'IDLE' | 'MEMINTA IZIN...' | 'ACTIVE' | 'ERROR'>('IDLE');
  
  // Audio configuration state
  const [audioMuted, setAudioMuted] = useState(false);

  // Auto-hiding HUD controls
  const [showControls, setShowControls] = useState(true);
  const controlsTimeoutRef = useRef<any>(null);

  // References
  const photoFrameRef = useRef<HTMLDivElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const lastSpawnRef = useRef<number>(0);
  
  // MediaPipe instance refs
  const handsInstanceRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // YouTube Player Ref
  const ytPlayerRef = useRef<any>(null);

  // Keep onResultsRef current to avoid stale closure in MediaPipe callback
  const onResultsRef = useRef<any>(null);

  // Load YouTube Iframe Player API dynamically
  useEffect(() => {
    // Add script tag if not exists
    if (!document.querySelector('script[src="https://www.youtube.com/iframe_api"]')) {
      const tag = document.createElement('script');
      tag.src = 'https://www.youtube.com/iframe_api';
      const firstScriptTag = document.getElementsByTagName('script')[0];
      firstScriptTag.parentNode?.insertBefore(tag, firstScriptTag);
    }

    // Set up global callback
    (window as any).onYouTubeIframeAPIReady = () => {
      ytPlayerRef.current = new (window as any).YT.Player('yt-hidden-player', {
        height: '1',
        width: '1',
        videoId: 'ELq8B0HHXKY',
        playerVars: {
          autoplay: 0,
          controls: 0,
          disablekb: 1,
          fs: 0,
          modestbranding: 1,
          rel: 0,
          showinfo: 0,
          start: 143, // Start at 2:23
        },
        events: {
          onReady: (event: any) => {
            event.target.setVolume(audioMuted ? 0 : 85);
          },
          onStateChange: (event: any) => {
            // Loop when ended or paused away from target
            if (event.data === (window as any).YT.PlayerState.ENDED) {
              event.target.seekTo(143, true);
              event.target.playVideo();
            }
          }
        }
      });
    };

    // If YT object is already loaded, initialize directly
    if ((window as any).YT && (window as any).YT.Player) {
      (window as any).onYouTubeIframeAPIReady();
    }

    return () => {
      (window as any).onYouTubeIframeAPIReady = null;
    };
  }, []);

  // Reset controls hide timer
  const resetControlsTimeout = () => {
    setShowControls(true);
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    controlsTimeoutRef.current = setTimeout(() => {
      setShowControls(false);
    }, 3000);
  };

  // Manage show/hide controls during active camera stream
  useEffect(() => {
    if (isCameraActive) {
      resetControlsTimeout();
    } else {
      setShowControls(true);
    }
    return () => {
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current);
      }
    };
  }, [isCameraActive]);

  useEffect(() => {
    if (!isCameraActive) return;

    const handleMouseMove = () => {
      resetControlsTimeout();
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, [isCameraActive]);

  // Sync volume of audio tracks
  useEffect(() => {
    const targetVol = audioMuted ? 0 : 0.85;
    audioBlur.volume = targetVol;
    audioLawan.volume = targetVol;
    audioAsing.volume = targetVol;
    audioTelunjuk.volume = targetVol;
    audioMetal.volume = targetVol;
    audioPlayer.globalMuted = audioMuted;
    synthFallback.setVolume(audioMuted ? 0 : 0.85);

    if (ytPlayerRef.current && ytPlayerRef.current.setVolume) {
      ytPlayerRef.current.setVolume(audioMuted ? 0 : 85);
    }
  }, [audioMuted]);

  // Periodic particle spawner for active modes (e.g. metal spawns 🫨)
  useEffect(() => {
    if (!isCameraActive) return;
    
    let interval: any = null;
    if (currentMode === 'metal') {
      interval = setInterval(() => {
        spawnParticles('🫨');
      }, 400);
    } else if (currentMode === 'lawan') {
      interval = setInterval(() => {
        spawnParticles('🔥');
      }, 600);
    } else if (currentMode === 'blur') {
      interval = setInterval(() => {
        spawnParticles('😍');
      }, 700);
    } else if (currentMode === 'telunjuk') {
      interval = setInterval(() => {
        spawnParticles('❓');
      }, 700);
    } else if (currentMode === 'mabuk') {
      interval = setInterval(() => {
        spawnParticles('😎');
      }, 750);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [currentMode, isCameraActive]);

  // Load MediaPipe SDK scripts sequentially
  const loadScript = (src: string): Promise<void> => {
    return new Promise((resolve, reject) => {
      const existing = document.querySelector(`script[src="${src}"]`);
      if (existing) {
        resolve();
        return;
      }
      const script = document.createElement('script');
      script.src = src;
      script.async = true;
      script.onload = () => resolve();
      script.onerror = (e) => reject(e);
      document.body.appendChild(script);
    });
  };

  // Particle Spawner matching User's Vanilla JS spec, but with safety throttle
  const spawnParticles = (emoji: string) => {
    if (!photoFrameRef.current) return;
    const frameRect = photoFrameRef.current.getBoundingClientRect();
    
    const now = performance.now();
    if (now - lastSpawnRef.current < 120) return;
    lastSpawnRef.current = now;

    for (let i = 0; i < 5; i++) {
      const particle = document.createElement('div');
      particle.className = 'particle';
      particle.innerText = emoji;
      
      const randomX = frameRect.left + Math.random() * frameRect.width;
      const randomY = frameRect.top + Math.random() * frameRect.height;
      
      particle.style.left = `${randomX}px`;
      particle.style.top = `${randomY}px`;
      
      document.body.appendChild(particle);
      
      setTimeout(() => {
        particle.remove();
      }, 1000);
    }
  };

  // Play sound function (matching User's spec but with mute safety and synth fallback)
  const playSound = (audioToPlay: any, audiosToStop: any[]) => {
    audiosToStop.forEach(audio => {
      audio.pause();
      audio.currentTime = 0;
    });
    
    if (audioMuted) {
      synthFallback.stop();
      return;
    }

    const modeType = 
      audioToPlay === audioBlur ? 'blur' : 
      audioToPlay === audioLawan ? 'lawan' : 
      audioToPlay === audioAsing ? 'mabuk' : 
      audioToPlay === audioTelunjuk ? 'telunjuk' : 'metal';

    if (audioToPlay.paused) {
      audioToPlay.currentTime = 0;
      audioToPlay.play()
        .then(() => {
          synthFallback.stop();
        })
        .catch(e => {
          console.warn('Playback blocked or failed, using synth fallback:', e);
          synthFallback.play(modeType);
        });
    }
  };

  // Stop all sounds (matching User's spec)
  const stopAllSound = () => {
    audioLawan.pause();
    audioBlur.pause();
    audioAsing.pause();
    audioTelunjuk.pause();
    audioMetal.pause();
    synthFallback.stop();
    if (ytPlayerRef.current && ytPlayerRef.current.pauseVideo) {
      ytPlayerRef.current.pauseVideo();
    }
  };

  // Mode status updater function (matching User's state rules & Apple emoticons)
  const updateState = (mode: 'normal' | 'blur' | 'lawan' | 'mabuk' | 'telunjuk' | 'metal') => {
    if (currentMode === mode) {
      if (mode === 'blur') spawnParticles('😍');
      if (mode === 'lawan') spawnParticles('😡');
      if (mode === 'mabuk') spawnParticles('😎');
      if (mode === 'telunjuk') spawnParticles('❓');
      if (mode === 'metal') spawnParticles('🫨');
      return;
    }
    
    setCurrentMode(mode);
    
    if (mode === 'normal') {
      stopAllSound();
    } 
    else if (mode === 'blur') {
      playSound(audioBlur, [audioLawan, audioAsing, audioTelunjuk, audioMetal]);
      if (ytPlayerRef.current && ytPlayerRef.current.pauseVideo) {
        ytPlayerRef.current.pauseVideo();
      }
    } 
    else if (mode === 'lawan') {
      playSound(audioLawan, [audioBlur, audioAsing, audioTelunjuk, audioMetal]);
      if (ytPlayerRef.current && ytPlayerRef.current.pauseVideo) {
        ytPlayerRef.current.pauseVideo();
      }
    }
    else if (mode === 'mabuk') {
      playSound(audioAsing, [audioBlur, audioLawan, audioTelunjuk, audioMetal]);
      if (ytPlayerRef.current && ytPlayerRef.current.pauseVideo) {
        ytPlayerRef.current.pauseVideo();
      }
    }
    else if (mode === 'telunjuk') {
      playSound(audioTelunjuk, [audioBlur, audioLawan, audioAsing, audioMetal]);
      if (ytPlayerRef.current && ytPlayerRef.current.pauseVideo) {
        ytPlayerRef.current.pauseVideo();
      }
    }
    else if (mode === 'metal') {
      playSound(audioMetal, [audioBlur, audioLawan, audioAsing, audioTelunjuk]);
      if (ytPlayerRef.current && ytPlayerRef.current.pauseVideo) {
        ytPlayerRef.current.pauseVideo();
      }
      for (let i = 0; i < 8; i++) {
        setTimeout(() => spawnParticles('🫨'), i * 80);
      }
    }
  };

  // MediaPipe hands classification onResults (matching User's exact coordinate calculations)
  const onResults = (results: any) => {
    if (!results.multiHandLandmarks || results.multiHandLandmarks.length === 0) {
      updateState('normal');
      return;
    }

    const landmarks = results.multiHandLandmarks[0];

    // Check if thumb is open (distance between thumb tip and index finger joint is large)
    const thumbOpen = Math.hypot(landmarks[4].x - landmarks[5].x, landmarks[4].y - landmarks[5].y) > 0.08;

    // Check individual fingers based on y joint coordinates
    const indexOpen = landmarks[8].y < landmarks[6].y;
    const middleOpen = landmarks[12].y < landmarks[10].y;
    const ringOpen = landmarks[16].y < landmarks[14].y;
    const pinkyOpen = landmarks[20].y < landmarks[18].y;

    const openedFingers = [indexOpen, middleOpen, ringOpen, pinkyOpen].filter(Boolean).length;

    if (openedFingers >= 3) { 
      updateState('normal');
    } else if (indexOpen && pinkyOpen && !middleOpen && !ringOpen) {
      updateState('metal');
    } else if (pinkyOpen && thumbOpen && !indexOpen && !middleOpen && !ringOpen) {
      updateState('mabuk');
    } else if (indexOpen && middleOpen && !ringOpen && !pinkyOpen) {
      updateState('blur');
    } else if (!indexOpen && !middleOpen && !ringOpen && !pinkyOpen) {
      updateState('lawan');
    } else if (indexOpen && !middleOpen && !ringOpen && !pinkyOpen) {
      updateState('telunjuk');
    } else {
      updateState('normal');
    }
  };

  // Sync onResultsRef with the latest onResults reference on every render
  useEffect(() => {
    onResultsRef.current = onResults;
  }, [onResults]);

  // Camera stream and MediaPipe frame capture loop
  // Camera stream and MediaPipe frame capture loop
  const detectFrame = async () => {
    if (!videoRef.current || !streamRef.current) return;
    
    try {
      if (handsInstanceRef.current && videoRef.current && videoRef.current.readyState >= 2) {
        await handsInstanceRef.current.send({ image: videoRef.current });
      }
    } catch (e) {
      console.error("Frame detection error:", e);
    }
    
    if (streamRef.current) {
      requestAnimationFrame(detectFrame);
    }
  };

  // Request stream & Start detection pipeline
  const startCameraFeed = async () => {
    setRequestState('MEMINTA IZIN...');
    setCameraLoading(true);
    setCameraError(null);

    // Initial audio activation to unlock browser
    audioLawan.play().then(() => audioLawan.pause()).catch(() => {});
    audioBlur.play().then(() => audioBlur.pause()).catch(() => {});
    audioAsing.play().then(() => audioAsing.pause()).catch(() => {});
    audioTelunjuk.play().then(() => audioTelunjuk.pause()).catch(() => {});
    audioMetal.play().then(() => audioMetal.pause()).catch(() => {});
    try {
      synthFallback.initCtx();
    } catch (e) {}

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setCameraError("Browser atau Protokol HTTP kamu tidak mendukung akses kamera. Pastikan menggunakan HTTPS.");
      setRequestState('ERROR');
      setCameraLoading(false);
      return;
    }

    try {
      await loadScript('https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js');
      await loadScript('https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js');

      const HandsClass = (window as any).Hands;
      if (!HandsClass) {
        throw new Error("Framework MediaPipe Hands gagal dimuat.");
      }

      const handsInstance = new HandsClass({
        locateFile: (file: string) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
      });

      handsInstance.setOptions({
        maxNumHands: 1,
        modelComplexity: 1,
        minDetectionConfidence: 0.5,
        minTrackingConfidence: 0.5
      });

      handsInstance.onResults((results: any) => {
        if (onResultsRef.current) {
          onResultsRef.current(results);
        }
      });
      handsInstanceRef.current = handsInstance;

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: "user"
        }
      });

      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          videoRef.current?.play();
          setIsCameraActive(true);
          setCameraLoading(false);
          setRequestState('ACTIVE');
          setIsSystemActive(true);
          requestAnimationFrame(detectFrame);
        };
      }
    } catch (err: any) {
      console.error(err);
      setCameraError(`Gagal mendeteksi kamera. Kode Error: ${err.name} - ${err.message}`);
      setRequestState('ERROR');
      setCameraLoading(false);
      setIsCameraActive(false);
    }
  };

  // Sync sounds state when user toggles mute or manually triggers options
  useEffect(() => {
    if (audioMuted) {
      stopAllSound();
    } else {
      if (currentMode === 'blur') {
        playSound(audioBlur, [audioLawan, audioAsing, audioTelunjuk, audioMetal]);
        if (ytPlayerRef.current && ytPlayerRef.current.pauseVideo) {
           ytPlayerRef.current.pauseVideo();
        }
      } else if (currentMode === 'lawan') {
        playSound(audioLawan, [audioBlur, audioAsing, audioTelunjuk, audioMetal]);
        if (ytPlayerRef.current && ytPlayerRef.current.pauseVideo) {
          ytPlayerRef.current.pauseVideo();
        }
      } else if (currentMode === 'mabuk') {
        playSound(audioAsing, [audioBlur, audioLawan, audioTelunjuk, audioMetal]);
        if (ytPlayerRef.current && ytPlayerRef.current.pauseVideo) {
          ytPlayerRef.current.pauseVideo();
        }
      } else if (currentMode === 'telunjuk') {
        playSound(audioTelunjuk, [audioBlur, audioLawan, audioAsing, audioMetal]);
        if (ytPlayerRef.current && ytPlayerRef.current.pauseVideo) {
          ytPlayerRef.current.pauseVideo();
        }
      } else if (currentMode === 'metal') {
        playSound(audioMetal, [audioBlur, audioLawan, audioAsing, audioTelunjuk]);
        if (ytPlayerRef.current && ytPlayerRef.current.pauseVideo) {
          ytPlayerRef.current.pauseVideo();
        }
      } else {
        stopAllSound();
      }
    }
  }, [audioMuted, currentMode]);

  return (
    <div className="relative min-h-screen bg-black flex flex-col overflow-hidden selection:bg-[#00FF00] selection:text-black font-sans">
      
      {/* Invisible YouTube Player Container for sound only */}
      <div className="absolute -top-10 -left-10 w-1 h-1 opacity-0 pointer-events-none overflow-hidden">
        <div id="yt-hidden-player" />
      </div>

      {/* FULL-SCREEN CAMERA BACKDROP / PHOTO-FRAME */}
      <div 
        ref={photoFrameRef}
        id="photo-frame"
        onClick={resetControlsTimeout}
        className={`fixed inset-0 w-full h-full z-0 photo-frame overflow-hidden bg-neutral-950 cursor-pointer ${
          currentMode === 'blur' ? 'state-blur' : 
          currentMode === 'lawan' ? 'state-lawan animate-shake' : 
          currentMode === 'telunjuk' ? 'state-telunjuk' : 
          currentMode === 'metal' ? 'state-metal animate-violent-shake' : ''
        }`}
      >
        {/* Full-screen Symmetrical Video */}
        <video
          ref={videoRef}
          className="absolute inset-0 w-full h-full object-cover pointer-events-none"
          playsInline
          muted
          style={{ opacity: isCameraActive ? 1 : 0 }}
        />

        {/* Ambient Grid overlay */}
        <div className="absolute inset-0 bg-[radial-gradient(#ffffff04_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none z-10" />

        {/* Metal Mode intense crimson overlay */}
        {currentMode === 'metal' && (
          <>
            <div className="absolute inset-0 bg-red-700/40 mix-blend-color-burn z-15 pointer-events-none animate-pulse" />
            <div className="absolute inset-0 bg-gradient-to-t from-red-950/80 via-transparent to-red-950/80 mix-blend-multiply z-15 pointer-events-none" />
          </>
        )}

        {/* Lawan / Battle Red Screen burn overlay */}
        {currentMode === 'lawan' && (
          <div className="absolute inset-0 bg-red-600/35 mix-blend-color-burn z-10 pointer-events-none" />
        )}
        
        {/* Blue Screen dream overlay */}
        {currentMode === 'blur' && (
          <div className="absolute inset-0 bg-cyan-900/25 mix-blend-screen z-10 pointer-events-none" />
        )}

        {/* Dizzy / Confused Yellow/Orange Screen overlay */}
        {currentMode === 'telunjuk' && (
          <div className="absolute inset-0 bg-yellow-600/15 mix-blend-color-dodge z-10 pointer-events-none" />
        )}

        {/* Confused / Dizzy Question Marks floating and spinning around */}
        {currentMode === 'telunjuk' && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-30">
            {/* Dizzy orbiting question marks */}
            <div className="absolute w-[300px] h-[300px] sm:w-[450px] sm:h-[450px] animate-[spin_6s_linear_infinite] flex items-center justify-center">
              <div className="absolute -top-10 text-5xl sm:text-6xl select-none animate-bounce">❓</div>
              <div className="absolute -bottom-10 text-5xl sm:text-6xl select-none animate-bounce delay-150">❓</div>
              <div className="absolute -left-10 text-5xl sm:text-6xl select-none animate-bounce delay-300">❓</div>
              <div className="absolute -right-10 text-5xl sm:text-6xl select-none animate-bounce delay-450">❓</div>
            </div>
            {/* Center question mark */}
            <div className="text-7xl sm:text-8xl text-yellow-400 opacity-60 font-black animate-ping select-none">❓</div>
          </div>
        )}



        {/* Moving Laser Scanline during battle mode */}
        {currentMode === 'lawan' && (
          <div className="absolute w-full h-1.5 bg-red-500 shadow-[0_0_20px_#ff0000] z-20 animate-scanline pointer-events-none" />
        )}
      </div>

      {/* BEFORE WEBCAM ACTIVATION COVER PANEL */}
      {!isCameraActive && (
        <div className="absolute inset-0 flex flex-col items-center justify-start p-4 sm:p-8 bg-zinc-950 z-30 overflow-y-auto">
          {/* Subtle Ambient Glow */}
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-[120px] pointer-events-none" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/5 rounded-full blur-[140px] pointer-events-none" />
          <div className="absolute inset-0 bg-[radial-gradient(#ffffff04_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none" />

          {/* Bento Grid Layout Container */}
          <div className="w-full max-w-5xl flex flex-col gap-6 z-40 my-auto py-8">
            
            {/* Row 1: Header block & Active start control */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              
              {/* Block 1: App Header (Spans 2 columns on desktop) */}
              <div className="md:col-span-2 bg-zinc-900/40 backdrop-blur-md border border-zinc-800/80 rounded-3xl p-6 sm:p-8 flex flex-col justify-between gap-6 relative overflow-hidden group">
                <div className="absolute -right-16 -top-16 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl group-hover:bg-emerald-500/15 transition-all duration-500" />
                <div className="flex flex-col gap-3">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse" />
                    <span className="font-mono text-xs text-emerald-400 font-bold uppercase tracking-widest">LIVE VISION SYSTEM v2.0</span>
                  </div>
                  <h1 className="text-4xl sm:text-5xl font-extrabold text-white leading-none tracking-tight font-display uppercase">
                    GESTURE.CAM <span className="text-emerald-400">🎥</span>
                  </h1>
                  <p className="text-sm text-zinc-400 leading-relaxed max-w-lg">
                    Transformasikan kamera Anda secara instan menggunakan gestur tangan cerdas. Diproses sepenuhnya secara privat dan aman di dalam browser Anda.
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-4 pt-4 border-t border-zinc-800/40 text-xs text-zinc-500 font-mono">
                  <div className="flex items-center gap-1.5">
                    <Shield className="w-4 h-4 text-emerald-500" />
                    <span>100% Privacy-First</span>
                  </div>
                  <span>•</span>
                  <span>Face & Hand Detection</span>
                  <span>•</span>
                  <span>Web Audio Core</span>
                </div>
              </div>

              {/* Block 2: Quick Start Camera Activation */}
              <div className="bg-gradient-to-br from-zinc-900/60 to-zinc-900/20 backdrop-blur-md border border-zinc-800 rounded-3xl p-6 flex flex-col justify-between gap-6 relative overflow-hidden group">
                <div className="flex flex-col gap-2">
                  <span className="font-mono text-[10px] text-zinc-500 font-bold uppercase tracking-widest block">PERANGKAT KERJA</span>
                  <h2 className="text-xl font-bold text-white tracking-tight">Mulai Eksperimen</h2>
                  <p className="text-xs text-zinc-400 leading-normal">
                    Berikan izin akses kamera untuk mengaktifkan pelacak AI interaktif.
                  </p>
                </div>

                <div className="flex flex-col gap-3">
                  {cameraError && (
                    <div className="bg-red-950/40 border border-red-500/20 p-3 rounded-2xl text-red-300 font-mono text-[10px] leading-relaxed">
                      <span className="font-bold flex items-center gap-1 text-red-400 mb-1">
                        <AlertTriangle className="w-3.5 h-3.5" /> ERROR:
                      </span>
                      {cameraError}
                    </div>
                  )}

                  <button
                    onClick={startCameraFeed}
                    disabled={cameraLoading}
                    className="w-full bg-emerald-400 hover:bg-emerald-300 text-black font-sans font-extrabold text-xs uppercase py-4 px-6 rounded-2xl transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer shadow-[0_4px_20px_rgba(16,185,129,0.2)] hover:shadow-[0_4px_25px_rgba(16,185,129,0.35)] active:scale-[0.98] disabled:opacity-50"
                  >
                    {cameraLoading ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin text-black" />
                        MENGHUBUNGKAN...
                      </>
                    ) : (
                      <>
                        <Camera className="w-4 h-4 stroke-[2.5]" />
                        AKTIFKAN KAMERA
                      </>
                    )}
                  </button>
                </div>
              </div>

            </div>

            {/* Row 2: Header title for bento items */}
            <div className="flex items-center gap-3 mt-4">
              <div className="h-[1px] bg-zinc-800/60 flex-1" />
              <span className="font-mono text-[10px] text-zinc-500 font-extrabold uppercase tracking-[0.2em] px-2">
                PANDUAN GESTUR & MODE EFEK
              </span>
              <div className="h-[1px] bg-zinc-800/60 flex-1" />
            </div>

            {/* Row 3: 6 Gesture Cards (Responsive Grid) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              
              {/* Normal Card */}
              <div className="bg-zinc-900/30 border border-zinc-800/60 hover:border-zinc-700/80 hover:bg-zinc-900/50 rounded-2xl p-5 flex flex-col justify-center items-center gap-3 transition-all duration-300 group">
                <div className="text-3xl shrink-0 bg-zinc-950 border border-zinc-800 w-16 h-16 flex items-center justify-center rounded-2xl shadow-inner group-hover:scale-110 transition-all duration-300">✋</div>
                <div className="flex flex-col text-center">
                  <span className="font-bold text-white text-sm">Tangan Terbuka</span>
                  <span className="font-mono text-[10px] text-emerald-400 uppercase tracking-widest font-black mt-1">NORMAL MODE</span>
                </div>
              </div>

              {/* Blur Card */}
              <div className="bg-zinc-900/30 border border-zinc-800/60 hover:border-cyan-500/30 hover:bg-zinc-900/50 rounded-2xl p-5 flex flex-col justify-center items-center gap-3 transition-all duration-300 group">
                <div className="text-3xl shrink-0 bg-zinc-950 border border-zinc-800 w-16 h-16 flex items-center justify-center rounded-2xl shadow-inner group-hover:scale-110 transition-all duration-300">✌️</div>
                <div className="flex flex-col text-center">
                  <span className="font-bold text-white text-sm">Pose Dua Jari</span>
                  <span className="font-mono text-[10px] text-cyan-400 uppercase tracking-widest font-black mt-1">BLUR MODE 😍</span>
                </div>
              </div>

              {/* Lawan Card */}
              <div className="bg-zinc-900/30 border border-zinc-800/60 hover:border-red-500/30 hover:bg-zinc-900/50 rounded-2xl p-5 flex flex-col justify-center items-center gap-3 transition-all duration-300 group">
                <div className="text-3xl shrink-0 bg-zinc-950 border border-zinc-800 w-16 h-16 flex items-center justify-center rounded-2xl shadow-inner group-hover:scale-110 transition-all duration-300">✊</div>
                <div className="flex flex-col text-center">
                  <span className="font-bold text-white text-sm">Kepalan Tangan</span>
                  <span className="font-mono text-[10px] text-red-500 uppercase tracking-widest font-black mt-1">AESTHETIC MODE 😡</span>
                </div>
              </div>

              {/* Asing Card */}
              <div className="bg-zinc-900/30 border border-zinc-800/60 hover:border-purple-500/30 hover:bg-zinc-900/50 rounded-2xl p-5 flex flex-col justify-center items-center gap-3 transition-all duration-300 group">
                <div className="text-3xl shrink-0 bg-zinc-950 border border-zinc-800 w-16 h-16 flex items-center justify-center rounded-2xl shadow-inner group-hover:scale-110 transition-all duration-300">🤙</div>
                <div className="flex flex-col text-center">
                  <span className="font-bold text-white text-sm">Ibu Jari & Kelingking</span>
                  <span className="font-mono text-[10px] text-purple-400 uppercase tracking-widest font-black mt-1">MODE ASING 😎</span>
                </div>
              </div>

              {/* Telunjuk Card */}
              <div className="bg-zinc-900/30 border border-zinc-800/60 hover:border-yellow-500/30 hover:bg-zinc-900/50 rounded-2xl p-5 flex flex-col justify-center items-center gap-3 transition-all duration-300 group">
                <div className="text-3xl shrink-0 bg-zinc-950 border border-zinc-800 w-16 h-16 flex items-center justify-center rounded-2xl shadow-inner group-hover:scale-110 transition-all duration-300">☝️</div>
                <div className="flex flex-col text-center">
                  <span className="font-bold text-white text-sm">Satu Jari Telunjuk</span>
                  <span className="font-mono text-[10px] text-yellow-400 uppercase tracking-widest font-black mt-1">MODE BINGUNG ❓</span>
                </div>
              </div>

              {/* Metal Card */}
              <div className="bg-zinc-900/30 border border-zinc-800/60 hover:border-rose-500/30 hover:bg-zinc-900/50 rounded-2xl p-5 flex flex-col justify-center items-center gap-3 transition-all duration-300 group">
                <div className="text-3xl shrink-0 bg-zinc-950 border border-zinc-800 w-16 h-16 flex items-center justify-center rounded-2xl shadow-inner group-hover:scale-110 transition-all duration-300">🤘</div>
                <div className="flex flex-col text-center">
                  <span className="font-bold text-white text-sm">Salam Tiga Jari</span>
                  <span className="font-mono text-[10px] text-rose-500 uppercase tracking-widest font-mono mt-1">ROCK MODE 🫨</span>
                </div>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* HUD OVERLAYS WITH SEPARATE ABSOLUTE/FIXED CONTAINERS TO PREVENT SCREEN INTERACTION BLOCKAGE */}
      {isCameraActive && (
        <>
          {/* Top-Right: Current Active Filter/Mode Status Badge */}
          <div 
            className={`fixed top-4 right-4 sm:top-6 sm:right-6 z-40 select-none font-mono transition-all duration-500 ease-in-out ${
              showControls ? 'opacity-100 translate-y-0 pointer-events-auto' : 'opacity-0 -translate-y-4 pointer-events-none'
            }`}
          >
            <div className="flex items-center gap-2 bg-black/75 border border-white/10 backdrop-blur-md px-3.5 py-2 rounded-lg text-white font-bold text-xs tracking-wider shadow-xl">
              <span className="text-neutral-400 font-medium text-[10px] sm:text-xs">FILTER:</span>
              <span className={`uppercase font-black text-[10px] sm:text-xs ${
                currentMode === 'normal' ? 'text-green-400' :
                currentMode === 'blur' ? 'text-cyan-300 animate-pulse' :
                currentMode === 'lawan' ? 'text-red-500 animate-pulse' :
                currentMode === 'mabuk' ? 'text-purple-400 animate-pulse' : 
                currentMode === 'telunjuk' ? 'text-yellow-400 animate-pulse' : 'text-rose-500 animate-pulse'
              }`}>
                {currentMode === 'normal' ? 'NORMAL ✋' :
                 currentMode === 'blur' ? 'BLUR 😍' :
                 currentMode === 'lawan' ? 'AESTHETIC 😡' :
                 currentMode === 'mabuk' ? 'ASING 😎' : 
                 currentMode === 'telunjuk' ? 'BINGUNG ☝️' : 'ROCK METAL 🤘'}
              </span>
            </div>
          </div>

          {/* Bottom-Left: Technical Camera Metadata Overlay */}
          <div 
            className={`fixed bottom-4 left-4 sm:bottom-6 sm:left-6 z-30 pointer-events-none select-none font-mono transition-all duration-500 ease-in-out ${
              showControls ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
          >
            <div className="flex flex-row flex-wrap items-center gap-x-5 gap-y-1 text-[10px] text-white/50 tracking-widest bg-black/55 backdrop-blur-xs px-3 py-1.5 rounded-md border border-white/5">
              <div className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping" />
                <span className="text-emerald-400 font-bold">LIVE</span>
              </div>
              <span>1080P 60FPS</span>
              <span className="hidden xs:inline">F2.8</span>
              <span className="hidden xs:inline">ISO 320</span>
              <span className="hidden md:inline">AUTO FOCUS</span>
            </div>
          </div>

          {/* Bottom-Right: Interactive Control Panel */}
          <div 
            className={`fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-40 flex items-center gap-3 font-mono transition-all duration-500 ease-in-out ${
              showControls ? 'opacity-100 translate-y-0 pointer-events-auto' : 'opacity-0 translate-y-4 pointer-events-none'
            }`}
          >
            
            {/* Compact Manual Mode Overrides */}
            <div className="flex items-center bg-black/75 border border-white/10 backdrop-blur-md p-1.5 rounded-xl gap-1 shadow-2xl">
              {(['normal', 'blur', 'lawan', 'mabuk', 'telunjuk', 'metal'] as const).map(m => (
                <button
                  key={m}
                  onClick={(e) => {
                    e.stopPropagation();
                    updateState(m);
                  }}
                  className={`w-8 h-8 flex items-center justify-center rounded-lg text-sm cursor-pointer transition-all ${
                    currentMode === m
                      ? 'bg-white text-black font-black scale-110 shadow-lg'
                      : 'bg-neutral-900/40 text-neutral-400 hover:text-white hover:bg-neutral-800'
                  }`}
                  title={`Ganti ke mode ${m}`}
                >
                  {m === 'normal' ? '✋' : m === 'blur' ? '✌️' : m === 'lawan' ? '✊' : m === 'mabuk' ? '🤙' : m === 'telunjuk' ? '☝️' : '🤘'}
                </button>
              ))}
            </div>

            {/* Audio Toggle button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                setAudioMuted(prev => !prev);
              }}
              className="w-11 h-11 flex items-center justify-center bg-black/75 border border-white/10 backdrop-blur-md hover:bg-neutral-900 text-white rounded-xl cursor-pointer transition-all shadow-2xl"
              title={audioMuted ? "Aktifkan Suara" : "Matikan Suara"}
            >
              {audioMuted ? <VolumeX className="w-5 h-5 text-red-400" /> : <Volume2 className="w-5 h-5 text-green-400" />}
            </button>

            {/* Exit/Power Button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                stopAllSound();
                setIsCameraActive(false);
                if (streamRef.current) {
                  streamRef.current.getTracks().forEach(t => t.stop());
                }
              }}
              className="w-11 h-11 flex items-center justify-center bg-red-600/85 hover:bg-red-600 border border-red-500 hover:border-red-400 text-white rounded-xl cursor-pointer transition-all shadow-2xl"
              title="Matikan Perangkat"
            >
              <Power className="w-5 h-5" />
            </button>

          </div>
        </>
      )}

    </div>
  );
}
