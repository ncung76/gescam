import React, { useEffect, useRef, useState } from 'react';
import { Camera, RefreshCw, AlertTriangle, Play, Pause, Check } from 'lucide-react';
import { GestureType } from '../types';

interface HandTrackerProps {
  onGestureDetected: (gesture: GestureType) => void;
  currentGesture: GestureType;
  isCameraActive: boolean;
  setIsCameraActive: (active: boolean) => void;
}

export default function HandTracker({
  onGestureDetected,
  currentGesture,
  isCameraActive,
  setIsCameraActive
}: HandTrackerProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [loading, setLoading] = useState(false);
  const [scriptsLoaded, setScriptsLoaded] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fps, setFps] = useState(0);

  const handsInstanceRef = useRef<any>(null);
  const cameraInstanceRef = useRef<any>(null);
  const lastFrameTimeRef = useRef<number>(0);

  // Dynamic script loader helper
  const loadScript = (src: string): Promise<void> => {
    return new Promise((resolve, reject) => {
      const existing = document.querySelector(`script[src="${src}"]`);
      if (existing) {
        resolve();
        return;
      }
      const script = document.createElement('script');
      script.src = src;
      script.async = true;
      script.onload = () => resolve();
      script.onerror = (e) => reject(e);
      document.body.appendChild(script);
    });
  };

  // Load MediaPipe scripts sequentially on component mount
  useEffect(() => {
    let active = true;
    const initScripts = async () => {
      setLoading(true);
      try {
        await loadScript('https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js');
        await loadScript('https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js');
        if (active) {
          setScriptsLoaded(true);
          setLoading(false);
        }
      } catch (err) {
        console.error('Failed to load MediaPipe Hand libraries:', err);
        if (active) {
          setError('Failed to load gesture-recognition engine. Check internet connection.');
          setLoading(false);
        }
      }
    };

    initScripts();

    return () => {
      active = false;
      // Stop camera if running
      if (cameraInstanceRef.current) {
        cameraInstanceRef.current.stop();
      }
    };
  }, []);

  // Initialize and run MediaPipe Camera and Hands
  useEffect(() => {
    if (!scriptsLoaded || !isCameraActive || !videoRef.current || !canvasRef.current) {
      if (cameraInstanceRef.current) {
        cameraInstanceRef.current.stop();
        cameraInstanceRef.current = null;
      }
      // Clear canvas if camera turns off
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
      }
      return;
    }

    const videoElement = videoRef.current;
    const canvasElement = canvasRef.current;
    const canvasCtx = canvasElement.getContext('2d');

    if (!canvasCtx) return;

    // Set up Hands options
    const HandsClass = (window as any).Hands;
    if (!HandsClass) {
      setError('MediaPipe Hands is not defined on window.');
      return;
    }

    try {
      const hands = new HandsClass({
        locateFile: (file: string) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
      });

      hands.setOptions({
        maxNumHands: 1,
        modelComplexity: 1,
        minDetectionConfidence: 0.55,
        minTrackingConfidence: 0.55
      });

      hands.onResults((results: any) => {
        if (!canvasElement || !canvasCtx) return;

        // Calculate FPS
        const now = performance.now();
        if (lastFrameTimeRef.current > 0) {
          const delta = now - lastFrameTimeRef.current;
          setFps(Math.round(1000 / delta));
        }
        lastFrameTimeRef.current = now;

        // Clear canvas
        canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);

        // Check if hand is detected
        if (!results.multiHandLandmarks || results.multiHandLandmarks.length === 0) {
          onGestureDetected('none');
          return;
        }

        const landmarks = results.multiHandLandmarks[0];

        // Draw Skeletal overlays
        drawSkeleton(canvasCtx, landmarks, canvasElement.width, canvasElement.height);

        // Perform hand gesture classification based on finger joint coordinate system
        classifyGesture(landmarks);
      });

      handsInstanceRef.current = hands;

      // Set up camera utils
      const CameraClass = (window as any).Camera;
      if (!CameraClass) {
        setError('MediaPipe Camera utility is not defined.');
        return;
      }

      const camera = new CameraClass(videoElement, {
        onFrame: async () => {
          if (videoElement && isCameraActive) {
            try {
              await hands.send({ image: videoElement });
            } catch (e) {
              // Ignore frames failing during stop/transition
            }
          }
        },
        width: 480,
        height: 360
      });

      camera.start()
        .then(() => {
          setError(null);
        })
        .catch((err: any) => {
          console.error('Camera play error:', err);
          setError('Camera access denied or device is already in use by another app.');
          setIsCameraActive(false);
        });

      cameraInstanceRef.current = camera;

    } catch (e: any) {
      console.error('Error starting MediaPipe setup:', e);
      setError('Error starting the neural network model: ' + e.message);
    }

    return () => {
      if (cameraInstanceRef.current) {
        cameraInstanceRef.current.stop();
        cameraInstanceRef.current = null;
      }
      onGestureDetected('none');
    };
  }, [scriptsLoaded, isCameraActive]);

  // Handle gesture classification
  const classifyGesture = (landmarks: any[]) => {
    // MediaPipe uses 0,0 at top-left. Lower y means HIGHER vertically.
    // Index finger: Tip(8) PIP(6)
    const indexOpen = landmarks[8].y < landmarks[6].y;
    // Middle finger: Tip(12) PIP(10)
    const middleOpen = landmarks[12].y < landmarks[10].y;
    // Ring finger: Tip(16) PIP(14)
    const ringOpen = landmarks[16].y < landmarks[14].y;
    // Pinky finger: Tip(20) PIP(18)
    const pinkyOpen = landmarks[20].y < landmarks[18].y;

    // Check if fingers are fully extended or folded
    // 2 Fingers (Victory sign)
    if (indexOpen && middleOpen && !ringOpen && !pinkyOpen) {
      onGestureDetected('two_fingers');
    }
    // Fist (all folded)
    else if (!indexOpen && !middleOpen && !ringOpen && !pinkyOpen) {
      onGestureDetected('fist');
    }
    // Open Hand (all extended)
    else if (indexOpen && middleOpen && ringOpen && pinkyOpen) {
      onGestureDetected('open_hand');
    }
    // Fallback or intermediate states
    else {
      // Keep state simple: if they hold up something else, treat as none
      onGestureDetected('none');
    }
  };

  // Draw bone skeletal connections and joint nodes
  const drawSkeleton = (ctx: CanvasRenderingContext2D, landmarks: any[], w: number, h: number) => {
    // 21 Joint connectors
    const connections = [
      [0, 1], [1, 2], [2, 3], [3, 4], // Thumb
      [0, 5], [5, 6], [6, 7], [7, 8], // Index
      [0, 9], [9, 10], [10, 11], [11, 12], // Middle
      [0, 13], [13, 14], [14, 15], [15, 16], // Ring
      [0, 17], [17, 18], [18, 19], [19, 20], // Pinky
      [5, 9], [9, 13], [13, 17] // Palm joints
    ];

    // Glow effects for brutalist high-contrast tech look
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#00FF66'; // Toxic Neon Green
    ctx.shadowColor = '#00FF66';
    ctx.shadowBlur = 10;

    for (const [start, end] of connections) {
      const pt1 = landmarks[start];
      const pt2 = landmarks[end];
      if (pt1 && pt2) {
        ctx.beginPath();
        // Since camera is mirrored for natural feel, we can mirror the X coordinates!
        const x1 = (1 - pt1.x) * w;
        const x2 = (1 - pt2.x) * w;
        ctx.moveTo(x1, pt1.y * h);
        ctx.lineTo(x2, pt2.y * h);
        ctx.stroke();
      }
    }

    // Draw individual nodes
    ctx.shadowBlur = 0; // Disable shadows for high-contrast crisp joints
    for (let i = 0; i < landmarks.length; i++) {
      const pt = landmarks[i];
      const x = (1 - pt.x) * w;
      const y = pt.y * h;

      const isTip = i === 4 || i === 8 || i === 12 || i === 16 || i === 20;

      ctx.beginPath();
      ctx.arc(x, y, isTip ? 7 : 5, 0, 2 * Math.PI);
      ctx.fillStyle = isTip ? '#FF0055' : '#FFFF00'; // Hot Pink tips, Neon Yellow joints
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = '#000000';
      ctx.stroke();
    }
  };

  const toggleCamera = () => {
    setIsCameraActive(!isCameraActive);
  };

  return (
    <div id="hand-tracker-section" className="bg-white border-4 border-black p-4 md:p-6 shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] flex flex-col gap-4 relative overflow-hidden">
      {/* Brutalist Ribbon */}
      <div className="absolute top-0 right-0 bg-yellow-300 border-b-4 border-l-4 border-black px-3 py-1 font-mono text-xs font-bold uppercase tracking-wider z-10">
        AI: Neural Vision
      </div>

      <div className="flex flex-col gap-1">
        <h3 className="font-sans text-xl font-extrabold uppercase tracking-tight text-black flex items-center gap-2">
          <Camera className="w-6 h-6 stroke-[3]" />
          WEBCAM INTERFACE
        </h3>
        <p className="font-mono text-xs text-gray-600">
          Capture real-time physical hand coordinates to trigger filter changes.
        </p>
      </div>

      {/* Main Preview Screen */}
      <div className="relative border-4 border-black bg-neutral-900 aspect-video w-full flex items-center justify-center overflow-hidden">
        {/* Mirrored webcam stream */}
        <video
          ref={videoRef}
          className="absolute inset-0 w-full h-full object-cover scale-x-[-1]"
          playsInline
          muted
          style={{ opacity: isCameraActive ? 0.35 : 0 }}
        />
        {/* Canvas overlays */}
        <canvas
          ref={canvasRef}
          width={480}
          height={360}
          className="absolute inset-0 w-full h-full object-cover pointer-events-none z-10"
        />

        {/* HUD Elements */}
        {isCameraActive && !error && !loading && (
          <div className="absolute bottom-2 left-2 right-2 flex justify-between items-end font-mono text-[10px] text-green-400 z-20 pointer-events-none bg-black/60 p-2 border border-green-400">
            <div className="flex flex-col gap-0.5">
              <div className="flex items-center gap-1.5 animate-pulse">
                <span className="w-2 h-2 rounded-full bg-green-500"></span>
                <span>SYSTEM ACTIVE (MIRRORED)</span>
              </div>
              <div>CAMERA: 480x360 @ {fps}fps</div>
            </div>
            <div className="text-right">
              <div>GESTURE: <span className="text-yellow-300 font-bold uppercase">{currentGesture === 'none' ? 'SCANNING...' : currentGesture.replace('_', ' ')}</span></div>
              <div>MODEL: MEDIAPIPE_HANDS_V1</div>
            </div>
          </div>
        )}

        {/* State messages inside screen */}
        {!isCameraActive && !loading && !error && (
          <div className="text-center p-6 flex flex-col items-center gap-3 z-10">
            <div className="w-16 h-16 rounded-full border-4 border-black bg-yellow-300 flex items-center justify-center shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
              <Camera className="w-8 h-8 text-black" />
            </div>
            <p className="font-mono text-xs text-neutral-400 max-w-xs leading-relaxed">
              Cam feed is offline. Fire up your camera to try computer-vision tracking!
            </p>
            <button
              id="start-camera-btn"
              onClick={toggleCamera}
              className="bg-emerald-400 hover:bg-emerald-300 text-black font-sans font-extrabold uppercase px-5 py-2.5 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] active:translate-x-[2px] active:translate-y-[2px] active:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-all flex items-center gap-2 cursor-pointer"
            >
              <Play className="w-4 h-4 fill-black" />
              START CAMERA FEED
            </button>
          </div>
        )}

        {loading && (
          <div className="flex flex-col items-center gap-3 text-center p-6 z-10">
            <RefreshCw className="w-12 h-12 text-yellow-300 animate-spin stroke-[3]" />
            <div className="font-mono font-bold text-yellow-300 text-sm tracking-wider uppercase animate-pulse">
              LOADING ML FRAMEWORKS...
            </div>
            <p className="font-mono text-[11px] text-gray-400 max-w-xs">
              Fetching MediaPipe model weights from Google's high-speed CDN.
            </p>
          </div>
        )}

        {error && (
          <div className="p-6 text-center flex flex-col items-center gap-3 z-10 max-w-sm">
            <div className="p-3 bg-red-500 border-4 border-black rounded-full shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
              <AlertTriangle className="w-8 h-8 text-white animate-bounce" />
            </div>
            <div className="font-mono font-extrabold text-red-500 text-sm uppercase tracking-wide">
              CAMERA INTERFACE ERROR
            </div>
            <p className="font-mono text-[11px] text-gray-300 leading-normal">
              {error}
            </p>
            <div className="flex flex-col gap-2 w-full mt-2">
              <button
                id="retry-camera-btn"
                onClick={toggleCamera}
                className="bg-yellow-300 hover:bg-yellow-200 text-black font-mono font-bold text-xs uppercase px-4 py-2 border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-x-[1px] active:translate-y-[1px] active:shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] transition-all cursor-pointer"
              >
                TRY AGAIN
              </button>
              <div className="text-[10px] text-yellow-400 font-mono">
                💡 Tip: You can always use the GESTURE SIMULATOR on the left instead!
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Action panel underneath camera */}
      {isCameraActive && !loading && !error && (
        <div className="flex flex-col gap-2 border-2 border-black bg-neutral-50 p-3">
          <div className="flex justify-between items-center">
            <span className="font-mono text-[11px] text-black font-bold uppercase">Webcam active:</span>
            <button
              id="pause-camera-btn"
              onClick={toggleCamera}
              className="bg-red-400 hover:bg-red-300 text-black font-mono font-extrabold text-xs uppercase px-3 py-1.5 border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:translate-x-[1px] active:translate-y-[1px] cursor-pointer"
            >
              <Pause className="w-3.5 h-3.5 inline mr-1" /> PAUSE CAMERA
            </button>
          </div>
        </div>
      )}

      {/* Mini tutorial on gestures inside neural panel */}
      <div className="border-2 border-dashed border-black/40 p-3 bg-neutral-50 flex flex-col gap-2">
        <h4 className="font-mono text-[11px] font-extrabold text-black uppercase">
          Neural Classification Reference:
        </h4>
        <div className="grid grid-cols-3 gap-2 font-mono text-[10px] text-neutral-700">
          <div className={`p-1.5 border ${currentGesture === 'open_hand' ? 'bg-emerald-100 border-emerald-400 font-bold text-black' : 'border-black/20 bg-white'}`}>
            🖐️ 5 FINGERS
            <div className="text-[8px] text-gray-500">NORMAL STYLING</div>
          </div>
          <div className={`p-1.5 border ${currentGesture === 'two_fingers' ? 'bg-cyan-100 border-cyan-400 font-bold text-black' : 'border-black/20 bg-white'}`}>
            ✌️ 2 FINGERS
            <div className="text-[8px] text-gray-500">BLUR FILTER + 😆</div>
          </div>
          <div className={`p-1.5 border ${currentGesture === 'fist' ? 'bg-red-100 border-red-400 font-bold text-black' : 'border-black/20 bg-white'}`}>
            ✊ FIST
            <div className="text-[8px] text-gray-500">BATTLE EFFECT + 🔥</div>
          </div>
        </div>
      </div>
    </div>
  );
}
