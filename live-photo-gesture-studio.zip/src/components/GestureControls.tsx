import React from 'react';
import { Terminal } from 'lucide-react';
import { GestureType } from '../types';

interface GestureControlsProps {
  currentGesture: GestureType;
  onGestureChange: (gesture: GestureType) => void;
  isCameraActive: boolean;
  setIsCameraActive: (active: boolean) => void;
}

export default function GestureControls({
  currentGesture,
  onGestureChange,
  isCameraActive,
  setIsCameraActive
}: GestureControlsProps) {

  const handleSimulate = (gesture: GestureType) => {
    // If simulating, disable camera to avoid conflicting with actual camera frames
    if (isCameraActive) {
      setIsCameraActive(false);
    }
    onGestureChange(gesture);
  };

  return (
    <div id="gesture-controls-section" className="flex flex-col gap-6">
      {/* Simulation & Instructions Combined into the styled Orange Aside Deck */}
      <div className="bg-[#FF5C00] border-8 border-black p-6 md:p-8 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] flex flex-col gap-6 relative">
        <div className="absolute top-0 right-0 bg-black text-[#00FF00] px-3 py-1 font-mono text-[10px] font-black uppercase tracking-widest border-b-4 border-l-4 border-black">
          EMULATOR // DIRECT CONTROL
        </div>

        <div>
          <h2 className="text-5xl font-black leading-[0.8] mb-2 uppercase italic text-black font-display tracking-tighter">
            Manual
          </h2>
          <p className="text-xs font-bold font-mono border-t-2 border-black pt-2 uppercase text-black">
            GESTURE RECOGNITION INTERFACE DECK
          </p>
        </div>

        <div className="flex flex-col gap-5">
          {/* STEP 01 - OPEN HAND / DEFAULT */}
          <button
            id="simulate-open-hand-btn"
            onClick={() => handleSimulate('open_hand')}
            className={`text-left border-4 border-black p-4 transition-all flex flex-col cursor-pointer select-none ${
              currentGesture === 'open_hand' && !isCameraActive
                ? 'bg-black text-[#00FF00] shadow-[4px_4px_0_#000] border-white translate-x-[2px] translate-y-[2px]'
                : 'bg-white text-black hover:bg-neutral-50 shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] active:translate-x-[2px] active:translate-y-[2px]'
            }`}
          >
            <div className="flex justify-between items-start mb-2 w-full">
              <span className="text-3xl font-black italic font-display leading-none">01</span>
              <span className="bg-black text-white px-2.5 text-[10px] font-bold py-1 font-mono uppercase tracking-wider">
                DEFAULT {currentGesture === 'open_hand' && !isCameraActive ? '★ ACTIVE' : ''}
              </span>
            </div>
            <h3 className="text-xl font-black uppercase leading-none mb-1 font-display tracking-tight">
              🖐️ Open Hand
            </h3>
            <p className="text-xs leading-tight font-semibold opacity-85">
              Restores natural frame visibility. Clears active filters and scatters.
            </p>
          </button>

          {/* STEP 02 - TWO FINGERS / EFFECT */}
          <button
            id="simulate-two-fingers-btn"
            onClick={() => handleSimulate('two_fingers')}
            className={`text-left border-4 border-black p-4 transition-all flex flex-col cursor-pointer select-none ${
              currentGesture === 'two_fingers' && !isCameraActive
                ? 'bg-black text-[#00FF00] shadow-[4px_4px_0_#000] border-white translate-x-[2px] translate-y-[2px]'
                : 'bg-white text-black hover:bg-neutral-50 shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] active:translate-x-[2px] active:translate-y-[2px]'
            }`}
          >
            <div className="flex justify-between items-start mb-2 w-full">
              <span className="text-3xl font-black italic font-display leading-none">02</span>
              <span className="bg-blue-400 text-black px-2.5 text-[10px] font-bold py-1 font-mono uppercase tracking-wider">
                EFFECT {currentGesture === 'two_fingers' && !isCameraActive ? '★ ACTIVE' : ''}
              </span>
            </div>
            <h3 className="text-xl font-black uppercase leading-none mb-1 font-display tracking-tight">
              ✌️ Two Fingers
            </h3>
            <p className="text-xs leading-tight font-semibold opacity-85">
              Initiates <span className="font-bold">BLUR_STATE</span>. Scatters 😆 emojis and triggers ambient sound.
            </p>
          </button>

          {/* STEP 03 - CLOSED FIST / WARNING */}
          <button
            id="simulate-fist-btn"
            onClick={() => handleSimulate('fist')}
            className={`text-left border-4 p-4 transition-all flex flex-col cursor-pointer select-none ${
              currentGesture === 'fist' && !isCameraActive
                ? 'bg-black text-[#00FF00] border-4 border-white shadow-[8px_8px_0_#000] translate-x-[2px] translate-y-[2px]'
                : 'bg-white text-black hover:bg-neutral-50 border-black shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] active:translate-x-[2px] active:translate-y-[2px]'
            }`}
          >
            <div className="flex justify-between items-start mb-2 w-full">
              <span className="text-3xl font-black italic font-display leading-none">03</span>
              <span className="bg-red-600 text-white px-2.5 text-[10px] font-bold py-1 font-mono uppercase tracking-wider">
                WARNING {currentGesture === 'fist' && !isCameraActive ? '★ ACTIVE' : ''}
              </span>
            </div>
            <h3 className="text-xl font-black uppercase leading-none mb-1 font-display tracking-tight">
              ✊ Closed Fist
            </h3>
            <p className="text-xs leading-tight font-semibold opacity-85">
              Enables <span className="font-bold">BATTLE_MODE</span>. Heavy fire emoji saturation and combat SFX.
            </p>
          </button>
        </div>

        {/* Info Deck Bottom strip */}
        <div className="mt-2 flex flex-col gap-2">
          <div className="flex gap-2">
            <div className="flex-1 h-2 bg-black"></div>
            <div className="flex-1 h-2 bg-black opacity-30"></div>
            <div className="flex-1 h-2 bg-black"></div>
          </div>
          <div className="text-[10px] font-black uppercase tracking-widest text-center text-black font-mono">
            System Core Ready: Secure Channel
          </div>
        </div>
      </div>
    </div>
  );
}
