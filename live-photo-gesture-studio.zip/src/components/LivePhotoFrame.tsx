import React, { useEffect, useState, useRef } from 'react';
import { ShieldAlert, Sparkles, Heart, RefreshCw, Eye, EyeOff, Volume2, VolumeX } from 'lucide-react';
import { GestureType, LivePhoto, Particle } from '../types';

interface LivePhotoFrameProps {
  activePhoto: LivePhoto;
  currentGesture: GestureType;
  audioMuted: boolean;
  toggleMute: () => void;
  volume: number;
  setVolume: (v: number) => void;
}

export default function LivePhotoFrame({
  activePhoto,
  currentGesture,
  audioMuted,
  toggleMute,
  volume,
  setVolume
}: LivePhotoFrameProps) {
  const [particles, setParticles] = useState<Particle[]>([]);
  const [clickCount, setClickCount] = useState(0);
  const [currentTime, setCurrentTime] = useState<string>('');

  // Update clock in brutalist metadata tracker
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString('en-US', { hour12: false }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Spawn emoji particles periodically based on gesture state
  useEffect(() => {
    if (currentGesture === 'none' || currentGesture === 'open_hand') {
      return;
    }

    const emoji = currentGesture === 'fist' ? '🔥' : '😆';
    const intervalTime = currentGesture === 'fist' ? 80 : 120; // faster fire particles

    const interval = setInterval(() => {
      const id = Date.now() + Math.random();
      const isBattle = emoji === '🔥';

      const newParticle: Particle = {
        id,
        emoji,
        // Emojis scatter beautifully
        x: isBattle ? 10 + Math.random() * 80 : Math.random() * 100,
        y: isBattle ? 40 + Math.random() * 40 : 105, // Spawn from middle-center for fist, bottom for blur
        size: isBattle ? 28 + Math.random() * 24 : 20 + Math.random() * 20,
        rotation: Math.random() * 360,
        speedY: isBattle ? (Math.random() * -8 - 3) : (Math.random() * -4 - 1.5), // Fire flies faster
        speedX: Math.random() * 6 - 3,
        opacity: 1.0
      };

      setParticles(prev => [...prev.slice(-35), newParticle]);
    }, intervalTime);

    return () => clearInterval(interval);
  }, [currentGesture]);

  // Update particles positions at 60 FPS
  useEffect(() => {
    let animFrame: number;

    const tick = () => {
      setParticles(prev =>
        prev
          .map(p => {
            const isFire = p.emoji === '🔥';
            return {
              ...p,
              x: p.x + p.speedX,
              y: p.y + p.speedY,
              rotation: p.rotation + p.speedX * 2,
              // Fire flickers/fades faster than smiles
              opacity: p.opacity - (isFire ? 0.025 : 0.015)
            };
          })
          .filter(p => p.opacity > 0 && p.y > -20 && p.x > -20 && p.x < 120)
      );
      animFrame = requestAnimationFrame(tick);
    };

    animFrame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animFrame);
  }, []);

  // Determine container classes based on gesture-induced modes
  const getFrameContainerClass = () => {
    let base = "relative border-8 border-black bg-neutral-950 aspect-[4/3] w-full overflow-hidden transition-all duration-300 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]";
    if (currentGesture === 'fist') {
      return `${base} animate-shake border-red-600 ring-4 ring-red-500`;
    }
    if (currentGesture === 'two_fingers') {
      return `${base} border-cyan-400 ring-4 ring-cyan-300`;
    }
    return base;
  };

  // Determine filters for the active image
  const getImageStyle = () => {
    if (currentGesture === 'fist') {
      return {
        filter: 'contrast(160%) saturate(200%) sepia(30%) hue-rotate(-20deg)',
        transform: 'scale(1.15)'
      };
    }
    if (currentGesture === 'two_fingers') {
      return {
        filter: 'blur(16px) saturate(130%) brightness(1.1)',
        transform: 'scale(1.05)'
      };
    }
    return {
      filter: 'blur(0px) contrast(100%) saturate(100%)',
      transform: 'scale(1.0)'
    };
  };

  return (
    <div id="live-photo-frame-container" className="flex flex-col gap-4">
      {/* Photo Frame Header (Brutalist style) */}
      <div className="flex flex-wrap justify-between items-end border-b-4 border-black pb-2">
        <div>
          <span className="font-mono text-xs font-black uppercase text-gray-500 tracking-wider">
            ACTIVE EXPOSITION // {activePhoto.vibe.toUpperCase()}
          </span>
          <h2 className="font-display text-2xl md:text-3xl font-black text-black leading-none uppercase">
            {activePhoto.title}
          </h2>
        </div>
        <div className="font-mono text-right text-xs text-black font-bold">
          <div>LOC: {activePhoto.location.toUpperCase()}</div>
          <div>CAPTURE: {activePhoto.year}</div>
        </div>
      </div>

      {/* Main Interactive Visual Frame */}
      <div className={getFrameContainerClass()}>
        {/* Underlay Grid */}
        <div className="absolute inset-0 bg-[radial-gradient(#ffffff08_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none z-0" />

        {/* Scanlines / Glitch filter */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[size:100%_4px,6px_100%] pointer-events-none z-30" />

        {/* Moving scanner line in normal/battle mode */}
        {currentGesture === 'fist' && (
          <div className="absolute w-full h-1 bg-red-500 shadow-[0_0_15px_#ff0000] z-20 animate-scanline pointer-events-none" />
        )}

        {/* Dynamic Image Canvas */}
        <div className="w-full h-full relative overflow-hidden flex items-center justify-center">
          <img
            id="live-photo-image"
            src={activePhoto.imageUrl}
            alt={activePhoto.title}
            referrerPolicy="no-referrer"
            style={getImageStyle()}
            className="w-full h-full object-cover transition-all duration-300 select-none animate-radial-drift"
          />

          {/* Battle Mode Overlay */}
          {currentGesture === 'fist' && (
            <div className="absolute inset-0 bg-red-600/30 mix-blend-color-burn z-10 pointer-events-none flex flex-col items-center justify-center border-4 border-red-500/80 animate-pulse">
              <div className="bg-black text-red-500 border-2 border-red-500 font-mono text-xs font-black tracking-widest uppercase px-4 py-2 flex items-center gap-2 shadow-[4px_4px_0px_rgba(0,0,0,1)]">
                <ShieldAlert className="w-4 h-4 animate-bounce text-red-500" />
                DANGER: BATTLE PROTOCOL ACTIVE
              </div>
            </div>
          )}

          {/* Blur Mode Overlay */}
          {currentGesture === 'two_fingers' && (
            <div className="absolute inset-0 bg-cyan-900/20 mix-blend-screen z-10 pointer-events-none flex items-center justify-center">
              <div className="bg-black text-cyan-400 border-2 border-cyan-400 font-mono text-xs font-black tracking-widest uppercase px-4 py-2 flex items-center gap-2 shadow-[4px_4px_0px_rgba(0,0,0,1)]">
                <Sparkles className="w-4 h-4 animate-spin text-cyan-400" />
                DREAM MODE: HARMONIC FREQUENCY
              </div>
            </div>
          )}
        </div>

        {/* Emoji Particles overlay */}
        <div className="absolute inset-0 z-20 pointer-events-none overflow-hidden">
          {particles.map(p => (
            <span
              key={p.id}
              style={{
                position: 'absolute',
                left: `${p.x}%`,
                top: `${p.y}%`,
                fontSize: `${p.size}px`,
                transform: `translate(-50%, -50%) rotate(${p.rotation}deg)`,
                opacity: p.opacity,
                filter: 'drop-shadow(2px 2px 0px rgba(0,0,0,1))'
              }}
              className="select-none leading-none"
            >
              {p.emoji}
            </span>
          ))}
        </div>

        {/* HUD Overlay corner tags */}
        <div className="absolute top-2 left-2 z-30 pointer-events-none font-mono text-[9px] bg-black text-white px-2 py-1 border border-black/50 select-none">
          STABILITY: {currentGesture === 'fist' ? '9.4%' : currentGesture === 'two_fingers' ? '78.2%' : '100%'}
        </div>

        <div className="absolute bottom-2 right-2 z-30 pointer-events-none font-mono text-[9px] bg-black text-white px-2 py-1 border border-black/50 select-none">
          SYS_TIME: {currentTime || '00:00:00'}
        </div>
      </div>

      {/* Frame details & description & sound indicators */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-2 border-4 border-black bg-white p-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] flex flex-col gap-2">
          <h4 className="font-mono text-xs font-black uppercase border-b-2 border-black pb-1 text-black flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-black" />
            VIBE DESCRIPTION
          </h4>
          <p className="font-sans text-sm font-semibold text-neutral-800 leading-relaxed">
            {activePhoto.description}
          </p>
        </div>

        {/* Audio control deck */}
        <div className="border-4 border-black bg-yellow-300 p-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] flex flex-col justify-between gap-3">
          <div className="flex justify-between items-center border-b-2 border-black pb-1">
            <span className="font-mono text-xs font-black text-black uppercase">SOUND TRACK</span>
            <button
              id="toggle-mute-btn"
              onClick={toggleMute}
              className="bg-black hover:bg-neutral-800 text-white p-1.5 border-2 border-black active:translate-x-[1px] active:translate-y-[1px] transition-all cursor-pointer"
              title={audioMuted ? "Unmute" : "Mute"}
            >
              {audioMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>

          {/* Equalizer lines reflecting gesture state */}
          <div className="flex items-end justify-between h-8 px-2 bg-black border-2 border-black">
            {[1, 2, 3, 4, 5, 6, 7, 8].map(i => {
              let height = 'h-1.5';
              let color = 'bg-green-400';
              if (!audioMuted) {
                if (currentGesture === 'fist') {
                  // High frequency violent bounce
                  height = i % 2 === 0 ? 'h-7 animate-pulse' : 'h-4 animate-pulse';
                  color = 'bg-red-500';
                } else if (currentGesture === 'two_fingers') {
                  // Slow, fluid wave
                  height = i % 3 === 0 ? 'h-5 animate-bounce' : 'h-2 animate-bounce';
                  color = 'bg-cyan-400';
                }
              }
              return (
                <div
                  key={i}
                  className={`w-1.5 ${height} ${color} transition-all duration-300`}
                  style={{ animationDelay: `${i * 0.08}s` }}
                />
              );
            })}
          </div>

          {/* Volume slider */}
          <div className="flex flex-col gap-1">
            <div className="flex justify-between text-[10px] font-mono font-bold text-black">
              <span>VOL: {audioMuted ? 'MUTED' : `${Math.round(volume * 100)}%`}</span>
              <span>100%</span>
            </div>
            <input
              id="volume-slider"
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={volume}
              onChange={e => setVolume(parseFloat(e.target.value))}
              disabled={audioMuted}
              className="w-full accent-black h-2 bg-neutral-100 border border-black rounded-none appearance-none cursor-pointer disabled:opacity-50"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
