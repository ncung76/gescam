import React from 'react';
import { ArrowRight } from 'lucide-react';
import { LivePhoto } from '../types';

interface PhotoSelectorProps {
  photos: LivePhoto[];
  selectedPhoto: LivePhoto;
  onSelectPhoto: (photo: LivePhoto) => void;
}

export default function PhotoSelector({
  photos,
  selectedPhoto,
  onSelectPhoto
}: PhotoSelectorProps) {
  return (
    <div id="photo-selector-section" className="bg-white border-8 border-black p-6 md:p-8 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] flex flex-col gap-6">
      <div className="flex flex-col gap-1 border-b-4 border-black pb-4">
        <h3 className="font-display text-4xl md:text-5xl font-black leading-[0.8] mb-2 uppercase italic text-black tracking-tighter">
          Collection
        </h3>
        <p className="font-mono text-xs text-gray-600 font-bold uppercase tracking-wider">
          CHOOSE AN ACTIVE ENVIRONMENTAL VECTOR TO MOUNT ON THE INTERACTIVE DECK
        </p>
      </div>

      {/* Grid of photos */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-2">
        {photos.map((photo, idx) => {
          const isSelected = photo.id === selectedPhoto.id;
          return (
            <button
              id={`photo-select-${photo.id}`}
              key={photo.id}
              onClick={() => onSelectPhoto(photo)}
              className={`text-left border-4 border-black transition-all flex flex-col overflow-hidden group shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] active:translate-x-[2px] active:translate-y-[2px] active:shadow-[2px_2px_0px_rgba(0,0,0,1)] cursor-pointer relative ${
                isSelected
                  ? 'bg-black text-[#00FF00] border-black ring-4 ring-[#00FF00]'
                  : 'bg-white hover:bg-neutral-50 text-black'
              }`}
            >
              {/* Index Number */}
              <div className="absolute top-2 left-2 z-20 bg-black text-white px-2 py-0.5 border border-white font-mono text-[10px] font-bold">
                0{idx + 1}
              </div>

              {/* Photo preview image */}
              <div className="aspect-[16/10] relative w-full overflow-hidden border-b-4 border-black bg-neutral-950">
                <img
                  src={photo.imageUrl}
                  alt={photo.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110 select-none opacity-90 group-hover:opacity-100"
                />
                <span className={`absolute top-2 right-2 font-mono text-[9px] font-black px-1.5 py-0.5 border-2 border-black uppercase shadow-[2px_2px_0px_rgba(0,0,0,1)] ${
                  photo.vibe === 'neon' ? 'bg-purple-400 text-black' :
                  photo.vibe === 'brutalist' ? 'bg-red-500 text-white' :
                  photo.vibe === 'chrome' ? 'bg-cyan-400 text-black' : 'bg-emerald-400 text-black'
                }`}>
                  {photo.vibe}
                </span>
              </div>

              {/* Photo card details */}
              <div className="p-4 flex flex-col gap-1.5 flex-1 justify-between">
                <div>
                  <h4 className="font-display font-black text-lg uppercase leading-tight tracking-tight">
                    {photo.title}
                  </h4>
                  <div className={`flex flex-col gap-0.5 mt-1 text-[10px] font-mono font-bold uppercase ${
                    isSelected ? 'text-neutral-400' : 'text-gray-500'
                  }`}>
                    <div>LOC: {photo.location}</div>
                    <div>YEAR: {photo.year}</div>
                  </div>
                </div>

                <div className="flex justify-end items-center mt-3 pt-2.5 border-t-2 border-black/10">
                  <span className={`font-mono text-[10px] font-black uppercase flex items-center gap-1.5 ${
                    isSelected ? 'text-[#00FF00]' : 'text-black'
                  }`}>
                    {isSelected ? 'SELECTED ✓' : 'LOAD DECK'}
                    <ArrowRight className="w-3.5 h-3.5 stroke-[3]" />
                  </span>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
