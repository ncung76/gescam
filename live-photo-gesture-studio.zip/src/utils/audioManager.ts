/**
 * AudioManager handles preloading, playing, looping, and crossfading 
 * of the Blur and Battle sound effects.
 */

class AudioManager {
  private blurAudio: HTMLAudioElement | null = null;
  private battleAudio: HTMLAudioElement | null = null;
  private isMuted: boolean = false;
  private volume: number = 0.8;
  private initialized: boolean = false;

  private BLUR_URL = 'https://cdn.ranzzawok.my.id/media/music/med_8b7250a727afaac0.mp3';
  private BATTLE_URL = 'https://cdn.ranzzawok.my.id/media/music/med_6cae0737736f3f08.mp3';

  init() {
    if (this.initialized) return;

    this.blurAudio = new Audio(this.BLUR_URL);
    this.blurAudio.loop = true;
    this.blurAudio.volume = this.isMuted ? 0 : this.volume;

    this.battleAudio = new Audio(this.BATTLE_URL);
    this.battleAudio.loop = true;
    this.battleAudio.volume = this.isMuted ? 0 : this.volume;

    this.initialized = true;
    console.log('Audio Manager Initialized');
  }

  setMute(mute: boolean) {
    this.isMuted = mute;
    const targetVol = mute ? 0 : this.volume;
    if (this.blurAudio) this.blurAudio.volume = targetVol;
    if (this.battleAudio) this.battleAudio.volume = targetVol;
  }

  setVolume(vol: number) {
    this.volume = vol;
    if (this.isMuted) return;
    if (this.blurAudio) this.blurAudio.volume = vol;
    if (this.battleAudio) this.battleAudio.volume = vol;
  }

  getVolume() {
    return this.volume;
  }

  getMuted() {
    return this.isMuted;
  }

  playBlur() {
    this.init();
    if (!this.blurAudio || !this.battleAudio) return;

    // Stop and reset battle audio
    this.battleAudio.pause();
    this.battleAudio.currentTime = 0;

    // Play blur audio safely
    this.blurAudio.play().catch(err => {
      console.warn('Audio play failed (waiting for user gesture):', err);
    });
  }

  playBattle() {
    this.init();
    if (!this.blurAudio || !this.battleAudio) return;

    // Stop and reset blur audio
    this.blurAudio.pause();
    this.blurAudio.currentTime = 0;

    // Play battle audio safely
    this.battleAudio.play().catch(err => {
      console.warn('Audio play failed (waiting for user gesture):', err);
    });
  }

  stopAll() {
    if (!this.initialized) return;
    if (this.blurAudio) {
      this.blurAudio.pause();
      this.blurAudio.currentTime = 0;
    }
    if (this.battleAudio) {
      this.battleAudio.pause();
      this.battleAudio.currentTime = 0;
    }
  }

  isBlurPlaying(): boolean {
    return this.initialized && this.blurAudio ? !this.blurAudio.paused : false;
  }

  isBattlePlaying(): boolean {
    return this.initialized && this.battleAudio ? !this.battleAudio.paused : false;
  }
}

export const audioManager = new AudioManager();
